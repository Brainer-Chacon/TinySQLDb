﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

public class APIInterface
{
    private TcpListener _server;
    private bool _isRunning;

    // Constructor que inicializa el servidor en una IP y puerto específicos
    public APIInterface(string ipAddress, int port)
    {
        IPAddress ip = IPAddress.Parse(ipAddress);
        _server = new TcpListener(ip, port);
    }

    // Método para iniciar el servidor y empezar a escuchar conexiones
    public void Start()
    {
        _server.Start();
        _isRunning = true;
        Console.WriteLine("Servidor iniciado y esperando conexiones...");

        // Comienza a aceptar clientes de manera asíncrona
        Task.Run(() => AcceptClientsAsync());
    }

    // Método para detener el servidor
    public void Stop()
    {
        _isRunning = false;
        _server.Stop();
        Console.WriteLine("Servidor detenido.");
    }

    // Método para aceptar clientes
    private async Task AcceptClientsAsync()
    {
        while (_isRunning)
        {
            try
            {
                var client = await _server.AcceptTcpClientAsync();
                Console.WriteLine("Cliente conectado.");
                _ = Task.Run(() => HandleClientAsync(client)); // Manejo asíncrono del cliente
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al aceptar cliente: {ex.Message}");
            }
        }
    }

    // Método para manejar cada cliente conectado
    private async Task HandleClientAsync(TcpClient client)
    {
        NetworkStream stream = null;
        try
        {
            stream = client.GetStream();
            byte[] buffer = new byte[1024]; // Buffer de tamaño fijo
            int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);

            // Convierte los datos recibidos en una cadena JSON
            string requestJson = Encoding.UTF8.GetString(buffer, 0, bytesRead);
            Console.WriteLine($"Consulta recibida: {requestJson}");

            // Procesar la consulta
            var responseJson = ProcessQuery(requestJson);

            // Enviar respuesta al cliente
            byte[] responseBytes = Encoding.UTF8.GetBytes(responseJson);
            await stream.WriteAsync(responseBytes, 0, responseBytes.Length);
            Console.WriteLine("Respuesta enviada al cliente.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error manejando cliente: {ex.Message}");
        }
        finally
        {
            // Cierra la conexión con el cliente
            stream?.Close();
            client.Close();
        }
    }

    // Método que procesa la consulta SQL (aquí se integraría el Query Processing)
    private string ProcessQuery(string queryJson)
    {
        try
        {
            // Deserializa la consulta desde JSON
            var query = JsonSerializer.Deserialize<QueryRequest>(queryJson);

            // Validar y procesar la consulta (esta parte es simplificada)
            string result = $"Processed query: {query.SqlQuery}";

            // Empaquetar el resultado en JSON
            var response = new QueryResponse { Success = true, Message = result };
            return JsonSerializer.Serialize(response);
        }
        catch (JsonException jsonEx)
        {
            // Manejo específico para errores de deserialización JSON
            var errorResponse = new QueryResponse { Success = false, Message = $"Error de deserialización: {jsonEx.Message}" };
            return JsonSerializer.Serialize(errorResponse);
        }
        catch (Exception ex)
        {
            // Si hay un error, se retorna un mensaje de error
            var errorResponse = new QueryResponse { Success = false, Message = ex.Message };
            return JsonSerializer.Serialize(errorResponse);
        }
    }
}

// Clases auxiliares para serialización JSON
public class QueryRequest
{
    public string SqlQuery { get; set; }
}

public class QueryResponse
{
    public bool Success { get; set; }
    public string Message { get; set; }
}

