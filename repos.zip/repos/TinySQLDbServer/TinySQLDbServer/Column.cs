﻿public class Column
{
    private string columnName;
    private ColumnType columnType;

    public string Name { get; private set; }
    public ColumnType Type { get; private set; }
    public bool IsNullable { get; private set; }

    // Constructor para inicializar la columna
    public Column(string name, ColumnType type, bool isNullable)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            throw new ArgumentException("El nombre de la columna no puede estar vacío.", nameof(name));
        }

        Name = name;
        Type = type;
        IsNullable = isNullable;
    }

    public Column(string columnName, ColumnType columnType)
    {
        this.columnName = columnName;
        this.columnType = columnType;
    }
}

public enum ColumnType
{
    INTEGER,
    DOUBLE,
    VARCHAR,
    DATETIME,
    STRING,
    DATE,
    INT,
    FLOAT
}

