﻿using System.Collections.Generic;

public class DatabaseCatalog
{
    private Dictionary<string, Table> _tables;

    public DatabaseCatalog()
    {
        _tables = new Dictionary<string, Table>();
    }

    // Agrega una nueva tabla al catálogo si no existe
    public void AddTable(string tableName, List<Column> columns)
    {
        if (!_tables.ContainsKey(tableName))
        {
            _tables[tableName] = new Table { Name = tableName, Columns = columns };
        }
        else
        {
            throw new InvalidOperationException($"Error: La tabla '{tableName}' ya existe.");
        }
    }

    // Obtiene la información de una tabla por su nombre
    public Table GetTableInfo(string tableName)
    {
        if (_tables.TryGetValue(tableName, out var table))
        {
            return table;
        }

        return null; // Devuelve null si no se encuentra la tabla
    }

    // Elimina una tabla del catálogo si existe
    public void RemoveTable(string tableName)
    {
        if (!_tables.Remove(tableName))
        {
            throw new KeyNotFoundException($"Error: La tabla '{tableName}' no existe.");
        }
    }

    // Lista todas las tablas en el catálogo (opcional)
    public List<string> ListTables()
    {
        return new List<string>(_tables.Keys);
    }
    // Método para verificar si una tabla existe
    public bool TableExists(string tableName)
    {
        return _tables.ContainsKey(tableName);
    }
}
