﻿using System;
using System.IO;
using System.Text.Json;

public class DatabaseManager
{
    private const string DatabaseFilePath = "database.json";
    private StoredDataManager _dataManager;
    private DatabaseCatalog _catalog;

    public DatabaseManager()
    {
        _dataManager = new StoredDataManager();
        _catalog = new DatabaseCatalog();

        // Carga los datos al inicializar
        LoadData();
    }

    public void LoadData()
    {
        if (File.Exists(DatabaseFilePath))
        {
            string json = File.ReadAllText(DatabaseFilePath);
            var databaseState = JsonSerializer.Deserialize<DatabaseState>(json);

            _dataManager = databaseState.DataManager; // Cargar el StoredDataManager
            _catalog = databaseState.Catalog; // Cargar el DatabaseCatalog
        }
    }

    public void SaveData()
    {
        var databaseState = new DatabaseState
        {
            DataManager = _dataManager,
            Catalog = _catalog
        };

        string json = JsonSerializer.Serialize(databaseState);
        File.WriteAllText(DatabaseFilePath, json);
    }

    public StoredDataManager GetDataManager() => _dataManager;
    public DatabaseCatalog GetCatalog() => _catalog;

    private class DatabaseState
    {
        public StoredDataManager DataManager { get; set; }
        public DatabaseCatalog Catalog { get; set; }
    }
}

