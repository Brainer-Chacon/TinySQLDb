﻿public class Query
{
    public QueryType Type { get; set; }          // Tipo de consulta (SELECT, INSERT, etc.)
    public string Database { get; set; }         // Nombre de la base de datos
    public Table Table { get; set; }             // Tabla afectada por la consulta
    public List<Column> Columns { get; set; }    // Columnas seleccionadas o afectadas
    public List<Dictionary<string, object>> Data { get; set; } // Datos a insertar o modificar (en caso de INSERT o UPDATE)

    // Constructor para inicializar una consulta
    public Query(QueryType type, string database, Table table, List<Dictionary<string, object>> data)
    {
        Type = type;
        Database = database;
        Table = table;
        Columns = new List<Column>();
        Data = new List<Dictionary<string, object>>();
    }
}

