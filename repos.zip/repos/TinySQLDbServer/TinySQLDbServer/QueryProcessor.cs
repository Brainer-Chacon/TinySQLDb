﻿using System;
using System.Collections.Generic;
using System.Text.Json;

public class QueryProcessor
{
    private readonly StoredDataManager _dataManager;
    private readonly DatabaseCatalog _catalog;

    public QueryProcessor(StoredDataManager dataManager, DatabaseCatalog catalog)
    {
        _dataManager = dataManager ?? throw new ArgumentNullException(nameof(dataManager));
        _catalog = catalog ?? throw new ArgumentNullException(nameof(catalog));
    }

    public string ProcessQuery(string queryString)
    {
        Query query;

        try
        {
            // Convierte la cadena de consulta en un objeto Query
            query = ParseQuery(queryString);
        }
        catch (Exception ex)
        {
            return $"Error al analizar la consulta: {ex.Message}";
        }

        if (!ValidateSyntax(query))
        {
            return "Error: Consulta SQL con sintaxis inválida.";
        }

        if (!ValidateSemantics(query))
        {
            return "Error: Semántica inválida (Tabla o columna no existe).";
        }

        switch (query.Type)
        {
            case QueryType.SELECT:
                return ExecuteSelect(query);
            case QueryType.CREATE:
                return ExecuteCreate(query);
            case QueryType.INSERT:
                return ExecuteInsert(query);
            case QueryType.DELETE:
                return ExecuteDelete(query);
            case QueryType.DROP:
                return ExecuteDrop(query);
            default:
                return "Error: Tipo de consulta no soportada.";
        }
    }

    private Query ParseQuery(string queryString)
    {
        // Convierte la cadena de consulta en un objeto Query
        string[] parts = queryString.Split(new[] { ' ', '(', ')' }, StringSplitOptions.RemoveEmptyEntries);

        // Determina el tipo de consulta
        if (!Enum.TryParse(parts[0].ToUpper(), out QueryType queryType))
        {
            throw new ArgumentException($"Tipo de consulta '{parts[0]}' no válido.");
        }

        // Inicializa el nombre de la tabla y las columnas
        string tableName = parts[2]; // Asumir que la tabla es la tercera palabra
        var columns = new List<Column>();
        var data = new List<Dictionary<string, object>>();

        if (queryType == QueryType.CREATE)
        {
            // Extraer las columnas de la consulta CREATE
            int startIndex = queryString.IndexOf('(');
            int endIndex = queryString.IndexOf(')', startIndex);

            if (startIndex == -1 || endIndex == -1 || endIndex < startIndex)
            {
                throw new ArgumentException("La definición de columnas está mal formada o faltan paréntesis.");
            }

            string columnDefinition = queryString.Substring(startIndex + 1, endIndex - startIndex - 1);
            string[] columnParts = columnDefinition.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (var columnPart in columnParts)
            {
                string[] columnInfo = columnPart.Trim().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                if (columnInfo.Length < 2)
                {
                    throw new ArgumentException("Definición de columna inválida.");
                }

                var columnName = columnInfo[0];
                var columnType = Enum.TryParse(columnInfo[1].ToUpper(), out ColumnType columnTypeValue)
                    ? columnTypeValue
                    : throw new ArgumentException($"Tipo de columna '{columnInfo[1]}' no válido.");

                // Crear una nueva instancia de Column usando el constructor
                columns.Add(new Column(columnName, columnType));
            }
        }
        else if (queryType == QueryType.INSERT)
        {
            // Extraer los valores de la inserción
            int startIndex = queryString.IndexOf('(');
            int endIndex = queryString.IndexOf(')', startIndex);

            if (startIndex == -1 || endIndex == -1 || endIndex < startIndex)
            {
                throw new ArgumentException("La definición de valores está mal formada o faltan paréntesis.");
            }

            string valueDefinition = queryString.Substring(startIndex + 1, endIndex - startIndex - 1);
            string[] valueParts = valueDefinition.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

            // Asegúrate de que las columnas se establezcan antes de esta parte
            // Verifica que la tabla existe en el catálogo
            if (!_catalog.TableExists(tableName))
            {
                throw new ArgumentException($"La tabla '{tableName}' no existe.");
            }

            // Obtener la información de la tabla
            var tableInfo = _catalog.GetTableInfo(tableName);

            // Verificar que el número de valores coincida con el número de columnas
            if (valueParts.Length != tableInfo.Columns.Count)
            {
                throw new ArgumentException($"Número de valores no coincide con el número de columnas en la tabla '{tableName}'. Se esperaban {tableInfo.Columns.Count} valores.");
            }

            // Creamos un nuevo diccionario para los valores
            var newData = new Dictionary<string, object>();

            for (int i = 0; i < valueParts.Length; i++)
            {
                string trimmedValue = valueParts[i].Trim();
                newData[tableInfo.Columns[i].Name] = ConvertValue(trimmedValue, tableInfo.Columns[i].Type) ?? throw new InvalidOperationException($"El valor para '{tableInfo.Columns[i].Name}' no se puede convertir.");
            }

            // Añadir el nuevo elemento a la lista de datos
            data.Add(newData);
        }

        // Crear el objeto Table
        var table = new Table { Name = tableName, Columns = columns };

        // Retornar el nuevo objeto Query
        return new Query(queryType, "nombre_de_base_de_datos", table, data);
    }

    private bool ValidateSyntax(Query query)
    {
        // Aquí se puede implementar una lógica básica para validar la sintaxis
        return true; // Asume que la sintaxis es válida (para simplificar)
    }

    private bool ValidateSemantics(Query query)
    {
        // Permitir la creación de la tabla
        if (query.Type == QueryType.CREATE)
        {
            return true; // Si es una consulta de creación, no validamos la existencia de la tabla
        }

        // Verificar que la tabla y las columnas existen en el catálogo
        var tableInfo = _catalog.GetTableInfo(query.Table.Name);
        if (tableInfo == null) return false;

        foreach (var column in query.Table.Columns)
        {
            if (!tableInfo.Columns.Exists(c => c.Name.Equals(column.Name, StringComparison.OrdinalIgnoreCase))) return false;
        }

        return true;
    }

    private string ExecuteSelect(Query query)
    {
        // Lógica para manejar SELECT
        var tableData = _dataManager.ReadTable(query.Table.Name);
        return JsonSerializer.Serialize(tableData);
    }

    private string ExecuteCreate(Query query)
    {
        // Verifica si la tabla ya existe
        if (_catalog.TableExists(query.Table.Name))
        {
            return $"Error: La tabla '{query.Table.Name}' ya existe.";
        }

        // Crea la tabla en el manejador de datos
        _dataManager.CreateTable(query.Table.Name, query.Table.Columns);

        // Agrega la tabla al catálogo
        _catalog.AddTable(query.Table.Name, query.Table.Columns);

        return $"Tabla '{query.Table.Name}' creada exitosamente.";
    }

    private string ExecuteInsert(Query query)
    {
        // Verifica que la tabla existe
        if (!_catalog.TableExists(query.Table.Name))
        {
            return $"Error: La tabla '{query.Table.Name}' no existe.";
        }

        // Obtener información de la tabla
        var tableInfo = _catalog.GetTableInfo(query.Table.Name);

        // Comprobar que la consulta tiene datos para insertar
        if (query.Data == null || query.Data.Count == 0)
        {
            return $"Error: No hay datos para insertar en la tabla '{query.Table.Name}'.";
        }

        // Crear una lista para almacenar los nuevos elementos
        var newItems = new List<Dictionary<string, object>>();

        // Extraer cada diccionario de datos
        foreach (var data in query.Data)
        {
            var newItem = new Dictionary<string, object>();

            // Asignar valores a las columnas correspondientes
            foreach (var columnInfo in tableInfo.Columns)
            {
                // Comprobar que el valor de la columna existe en el dato proporcionado
                if (data.TryGetValue(columnInfo.Name, out var value))
                {
                    // Convertir el valor y agregarlo al nuevo elemento
                    newItem[columnInfo.Name] = ConvertValue(value.ToString(), columnInfo.Type)
                        ?? throw new InvalidOperationException($"El valor para '{columnInfo.Name}' no se puede convertir.");
                }
                else
                {
                    // Si no se proporciona un valor para una columna, asignar null o un valor predeterminado según el tipo
                    newItem[columnInfo.Name] = GetDefaultValue(columnInfo.Type);
                }
            }

            newItems.Add(newItem);
        }

        // Escribir los datos en el archivo JSON
        _dataManager.WriteTable(query.Table.Name, newItems);
        return $"Datos insertados en la tabla '{query.Table.Name}'.";
    }

    private object GetDefaultValue(ColumnType type)
    {
        // Retornar un valor predeterminado según el tipo de columna
        return type switch
        {
            ColumnType.INT => 0,
            ColumnType.STRING => string.Empty,
            ColumnType.FLOAT => 0.0f,
            _ => null
        };
    }

    private string ExecuteDelete(Query query)
    {
        // Verifica que la tabla existe
        if (!_catalog.TableExists(query.Table.Name))
        {
            return $"Error: La tabla '{query.Table.Name}' no existe.";
        }

        // Obtener información de la tabla
        var tableInfo = _catalog.GetTableInfo(query.Table.Name);

        // Aquí asumimos que la consulta incluye una condición en forma de clave-valor para el filtro
        if (query.Data.Count == 0)
        {
            return $"Error: No se especificó ninguna condición para eliminar registros de la tabla '{query.Table.Name}'.";
        }

        var condition = query.Data[0]; // Suponiendo que la condición es el primer elemento de Data
        var recordsToDelete = _dataManager.ReadTable(query.Table.Name);
        var recordsToKeep = new List<Dictionary<string, object>>();

        foreach (var record in recordsToDelete)
        {
            // Comprobar si el registro cumple la condición
            bool shouldDelete = true;

            foreach (var key in condition.Keys)
            {
                if (record.TryGetValue(key, out var value))
                {
                    if (!value.Equals(condition[key]))
                    {
                        shouldDelete = false; // No coincide, no se debe eliminar
                        break;
                    }
                }
                else
                {
                    shouldDelete = false; // No existe la clave en el registro
                    break;
                }
            }

            if (!shouldDelete)
            {
                recordsToKeep.Add(record); // Mantener el registro si no cumple la condición
            }
        }

        // Guardar los registros restantes
        _dataManager.WriteTable(query.Table.Name, recordsToKeep);

        return $"Registros eliminados de la tabla '{query.Table.Name}'.";
    }

    private string ExecuteDrop(Query query)
    {
        // Verifica que la tabla existe
        if (!_catalog.TableExists(query.Table.Name))
        {
            return $"Error: La tabla '{query.Table.Name}' no existe.";
        }

        // Eliminar la tabla del catálogo
        _catalog.RemoveTable(query.Table.Name);

        // También eliminar el archivo asociado a la tabla
        _dataManager.DeleteTableFile(query.Table.Name);

        return $"Tabla '{query.Table.Name}' eliminada exitosamente.";
    }


    private object ConvertValue(string value, ColumnType type)
    {
        // Implementar lógica para convertir el valor según el tipo de columna
        return type switch
        {
            ColumnType.INT => int.TryParse(value, out var intValue) ? intValue : null,
            ColumnType.STRING => value,
            ColumnType.FLOAT => float.TryParse(value, out var floatValue) ? floatValue : null,
            _ => null
        };
    }
}
