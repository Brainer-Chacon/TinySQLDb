﻿public enum QueryType
{
    SELECT,
    INSERT,
    CREATE,
    DROP,
    UPDATE,
    DELETE
}
