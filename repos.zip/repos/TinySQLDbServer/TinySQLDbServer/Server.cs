﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

public class Server
{
    private int port;
    private IPAddress ipAddress;
    private QueryProcessor queryProcessor;
    private DatabaseManager databaseManager; // Agrega la referencia al DatabaseManager

    public Server(string ip, int port, DatabaseManager dbManager)
    {
        this.ipAddress = IPAddress.Parse(ip);
        this.port = port;
        this.databaseManager = dbManager; // Inicializa el DatabaseManager
        this.queryProcessor = new QueryProcessor(dbManager.GetDataManager(), dbManager.GetCatalog()); // Usa el DataManager y Catalog del DatabaseManager
    }

    public void Start()
    {
        // Carga los datos desde el archivo al iniciar el servidor
        databaseManager.LoadData();

        TcpListener listener = new TcpListener(ipAddress, port);
        listener.Start();
        Console.WriteLine($"Servidor iniciado en {ipAddress}:{port}");

        while (true)
        {
            Console.WriteLine("Esperando conexión...");
            TcpClient client = listener.AcceptTcpClient();
            Console.WriteLine("Cliente conectado.");

            Task.Run(() => HandleClient(client));
        }
    }

    private void HandleClient(TcpClient client)
    {
        try
        {
            NetworkStream stream = client.GetStream();
            byte[] buffer = new byte[1024];
            int byteCount;

            byteCount = stream.Read(buffer, 0, buffer.Length);
            string query = Encoding.ASCII.GetString(buffer, 0, byteCount);
            Console.WriteLine($"Consulta recibida: {query}");

            string result = queryProcessor.ProcessQuery(query);

            byte[] response = Encoding.ASCII.GetBytes(result);
            stream.Write(response, 0, response.Length);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error al manejar el cliente: {ex.Message}");
        }
        finally
        {
            client.Close();
            Console.WriteLine("Cliente desconectado.");
        }
    }

    // Método para cerrar el servidor y guardar los datos
    public void Stop()
    {
        databaseManager.SaveData(); // Guarda los datos en el archivo
        Console.WriteLine("Servidor detenido y datos guardados.");
    }

    public static void Main(string[] args)
    {
        string ip = "127.0.0.1";
        int port = 8000;
        var databaseManager = new DatabaseManager(); // Inicializa el DatabaseManager

        Server server = new Server(ip, port, databaseManager);
        server.Start();
    }
}
