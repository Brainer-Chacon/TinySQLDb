﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

public class StoredDataManager
{
    private string _baseDirectory;

    public StoredDataManager(string baseDirectory)
    {
        _baseDirectory = baseDirectory;
    }

    public StoredDataManager() : this(Directory.GetCurrentDirectory()) { } // Uso de directorio actual por defecto

    public List<Dictionary<string, object>> ReadTable(string tableName)
    {
        // Lee el archivo de la tabla y convierte los datos en una lista de diccionarios
        string filePath = GetTableFilePath(tableName);
        if (File.Exists(filePath))
        {
            try
            {
                string json = File.ReadAllText(filePath);
                return JsonSerializer.Deserialize<List<Dictionary<string, object>>>(json) ?? new List<Dictionary<string, object>>();
            }
            catch (Exception ex)
            {
                // Manejo de errores en la lectura del archivo
                throw new IOException($"Error al leer la tabla '{tableName}': {ex.Message}", ex);
            }
        }
        return new List<Dictionary<string, object>>(); // Retorna una lista vacía si no existe
    }

    public void WriteTable(string tableName, List<Dictionary<string, object>> data)
    {
        // Escribe datos en el archivo de la tabla
        string filePath = GetTableFilePath(tableName);
        try
        {
            string json = JsonSerializer.Serialize(data);
            File.WriteAllText(filePath, json);
        }
        catch (Exception ex)
        {
            // Manejo de errores en la escritura del archivo
            throw new IOException($"Error al escribir en la tabla '{tableName}': {ex.Message}", ex);
        }
    }

    public void CreateTable(string tableName, List<Column> columns)
    {
        if (string.IsNullOrWhiteSpace(tableName))
        {
            throw new ArgumentException("El nombre de la tabla no puede estar vacío.", nameof(tableName));
        }

        // Verificar si ya existe una tabla con ese nombre
        string filePath = GetTableFilePath(tableName);
        if (File.Exists(filePath))
        {
            throw new InvalidOperationException($"La tabla '{tableName}' ya existe.");
        }

        // Crea un archivo vacío para la tabla
        try
        {
            File.WriteAllText(filePath, "[]"); // Crear archivo vacío
        }
        catch (Exception ex)
        {
            throw new IOException($"Error al crear la tabla '{tableName}': {ex.Message}", ex);
        }
    }

    public void DeleteTable(string tableName)
    {
        // Elimina el archivo de la tabla
        string filePath = GetTableFilePath(tableName);
        if (File.Exists(filePath))
        {
            try
            {
                File.Delete(filePath);
            }
            catch (Exception ex)
            {
                throw new IOException($"Error al eliminar la tabla '{tableName}': {ex.Message}", ex);
            }
        }
        else
        {
            throw new FileNotFoundException($"La tabla '{tableName}' no existe.");
        }
    }

    public int DeleteFromTable(string tableName, string conditions)
    {
        if (!File.Exists(GetTableFilePath(tableName)))
        {
            throw new FileNotFoundException($"La tabla '{tableName}' no existe.");
        }

        var data = ReadTable(tableName);
        int originalCount = data.Count;

        // Lógica para evaluar las condiciones
        List<Dictionary<string, object>> recordsToDelete = new List<Dictionary<string, object>>();
        foreach (var record in data)
        {
            if (EvaluateCondition(record, conditions))
            {
                recordsToDelete.Add(record);
            }
        }

        // Eliminar los registros
        foreach (var record in recordsToDelete)
        {
            data.Remove(record);
        }

        WriteTable(tableName, data); // Guardar cambios en la tabla

        // Retornar el número de registros eliminados
        return originalCount - data.Count;
    }

    private bool EvaluateCondition(Dictionary<string, object> record, string conditions)
    {
        // Implementar lógica para evaluar las condiciones.
        // Por ejemplo, podrías hacer un parsing de "id = 1" a un comparador que verifica el id en el diccionario `record`.

        string[] conditionParts = conditions.Split(new[] { '=' }, StringSplitOptions.RemoveEmptyEntries);
        if (conditionParts.Length != 2)
        {
            throw new ArgumentException("Condiciones mal formadas.");
        }

        string fieldName = conditionParts[0].Trim();
        string fieldValue = conditionParts[1].Trim();

        if (record.ContainsKey(fieldName) && record[fieldName].ToString() == fieldValue)
        {
            return true; // Coincide con la condición
        }

        return false; // No coincide
    }

    // Método privado para obtener la ruta del archivo de la tabla
    private string GetTableFilePath(string tableName)
    {
        return Path.Combine(_baseDirectory, tableName + ".json");
    }

    internal int DeleteFromTable(string name, List<Dictionary<string, object>> data)
    {
        throw new NotImplementedException();
    }

    internal void DeleteTableFile(string name)
    {
        throw new NotImplementedException();
    }
}

