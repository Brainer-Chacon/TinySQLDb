﻿public class Table
{
    public string Name { get; set; }
    public List<Column> Columns { get; set; }
    public List<Dictionary<string, object>> Data { get; set; } = new List<Dictionary<string, object>>();
}

