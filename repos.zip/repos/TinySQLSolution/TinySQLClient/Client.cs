﻿using System;
using System.Net.Sockets;
using System.Text;

public class Client
{
    private string serverIp;
    private int serverPort;

    public Client(string serverIp, int serverPort)
    {
        this.serverIp = serverIp;
        this.serverPort = serverPort;
    }

    public void SendQuery(string query)
    {
        try
        {
            TcpClient client = new TcpClient(serverIp, serverPort);
            NetworkStream stream = client.GetStream();

            // Enviar la consulta al servidor
            byte[] queryBytes = Encoding.ASCII.GetBytes(query);
            stream.Write(queryBytes, 0, queryBytes.Length);
            Console.WriteLine($"Consulta enviada: {query}");

            // Recibir la respuesta del servidor
            byte[] buffer = new byte[1024];
            int bytesRead = stream.Read(buffer, 0, buffer.Length);
            string response = Encoding.ASCII.GetString(buffer, 0, bytesRead);
            Console.WriteLine($"Respuesta del servidor: {response}");

            stream.Close();
            client.Close();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error al enviar la consulta: {ex.Message}");
        }
    }

    // Método estático para iniciar el cliente
    public static void Main(string[] args)
    {
        string serverIp = "127.0.0.1";
        int serverPort = 8000;

        Client client = new Client(serverIp, serverPort);

        // Loop para permitir al usuario enviar consultas
        while (true)
        {
            Console.WriteLine("Ingrese su consulta SQL (o 'exit' para salir):");
            string query = Console.ReadLine();
            if (query.Equals("exit", StringComparison.OrdinalIgnoreCase)) break;

            client.SendQuery(query);
        }
    }
}

