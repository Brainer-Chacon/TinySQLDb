param (
    [Parameter(Mandatory = $true)]
    [string]$IP,
    [Parameter(Mandatory = $true)]
    [int]$Port
)

# Crear el endpoint con los par�metros proporcionados
$ipEndPoint = [System.Net.IPEndPoint]::new([System.Net.IPAddress]::Parse($IP), $Port)

# Funci�n para verificar si la tabla existe
function Check-TableExists {
    param (
        [string]$TableName,
        [string]$IP,
        [int]$Port
    )

    $query = "SELECT COUNT(*) FROM information_schema.tables WHERE table_name = '$TableName';"
    $result = Send-SQLCommand -command $query -IP $IP -Port $Port

    return $result -eq 1
}

# Funci�n para enviar mensajes al servidor
function Send-Message {
    param (
        [Parameter(Mandatory=$true)]
        [pscustomobject]$message,
        [Parameter(Mandatory=$true)]
        [System.Net.Sockets.Socket]$client
    )

    $stream = New-Object System.Net.Sockets.NetworkStream($client)
    $writer = New-Object System.IO.StreamWriter($stream)
    try {
        $writer.WriteLine($message)
    }
    finally {
        $writer.Close()
        $stream.Close()
    }
}

# Funci�n para recibir mensajes del servidor
function Receive-Message {
    param (
        [System.Net.Sockets.Socket]$client
    )
    $stream = New-Object System.Net.Sockets.NetworkStream($client)
    $reader = New-Object System.IO.StreamReader($stream)
    try {
        return $null -ne $reader.ReadLine() ? $reader.ReadLine() : ""
    }
    finally {
        $reader.Close()
        $stream.Close()
    }
}

# Funci�n para enviar un comando SQL y recibir el resultado
function Send-SQLCommand {
    param (
        [string]$command,
        [string]$IP,
        [int]$Port
    )

    $client = New-Object System.Net.Sockets.Socket($ipEndPoint.AddressFamily, [System.Net.Sockets.SocketType]::Stream, [System.Net.Sockets.ProtocolType]::Tcp)
    $client.Connect($ipEndPoint)

    $requestObject = [PSCustomObject]@{
        RequestType = 0;
        RequestBody = $command
    }
    $jsonMessage = ConvertTo-Json -InputObject $requestObject -Compress
    Send-Message -client $client -message $jsonMessage
    $response = Receive-Message -client $client

    $client.Shutdown([System.Net.Sockets.SocketShutdown]::Both)
    $client.Close()

    return $response
}

# Funci�n para crear la tabla Users si no existe
function Create-UsersTable {
    param (
        [string]$IP,
        [int]$Port
    )

    $tableName = "Users"

    # Verifica si la tabla ya existe
    if (-not (Check-TableExists -TableName $tableName -IP $IP -Port $Port)) {
        $createTableSQL = @"
CREATE TABLE Users (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    Name VARCHAR(100),
    Email VARCHAR(100) UNIQUE,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);
"@

        # Intenta crear la tabla
        try {
            $response = Send-SQLCommand -command $createTableSQL -IP $IP -Port $Port
            Write-Host -ForegroundColor Green "Tabla '$tableName' creada con �xito."
        } catch {
            Write-Host -ForegroundColor Red "Error al crear la tabla '$tableName': $_"
        }
    } else {
        Write-Host -ForegroundColor Yellow "La tabla '$tableName' ya existe. No se cre� una nueva."
    }
}

# Crear la tabla Users si no existe
Create-UsersTable -IP $IP -Port $Port

# Solo despu�s de verificar la creaci�n de la tabla, permite al usuario ingresar consultas
while ($true) {
    $query = Read-Host -Prompt "Ingrese su consulta SQL (o 'exit' para salir)"
    if ($query -eq 'exit') { break }

    # Ejecutar la consulta
    Write-Host -ForegroundColor Green "`nEjecutando consulta: $query"
    
    # Medir el tiempo de ejecuci�n
    $executionTime = Measure-Command {
        $response = Send-SQLCommand -command $query -IP $IP -Port $Port
    }

    # Convertir la respuesta en objeto PowerShell
    $responseObject = ConvertFrom-Json -InputObject $response

    # Mostrar el resultado en formato tabla
    if ($responseObject -and $responseObject.result) {
        $responseObject.result | Format-Table -AutoSize
    } else {
        Write-Host -ForegroundColor Red "Error en la ejecuci�n o respuesta vac�a."
    }

    # Mostrar el tiempo que tard� la ejecuci�n
    Write-Host -ForegroundColor Yellow "Tiempo de ejecuci�n: $($executionTime.TotalMilliseconds) ms"
}
